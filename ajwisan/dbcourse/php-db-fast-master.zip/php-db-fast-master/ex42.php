<?php
$newURL = "Update_Form.html";
header('Location: '.$newURL);
?>