<?php
$newURL = "Insert_Form.html";
header('Location: '.$newURL);
?>