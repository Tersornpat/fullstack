<?php
$newURL = "Delete_Form.html";
header('Location: '.$newURL);
?>