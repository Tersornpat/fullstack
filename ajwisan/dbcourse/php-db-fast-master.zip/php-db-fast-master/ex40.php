<?php
$newURL = "Select_Form.html";
header('Location: '.$newURL);
?>